export { default } from './CustomColor2';
