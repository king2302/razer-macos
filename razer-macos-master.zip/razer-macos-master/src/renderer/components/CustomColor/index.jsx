export { default } from './CustomColor';
