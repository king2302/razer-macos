export { default } from './MouseSensitivity';
