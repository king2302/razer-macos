/**
 * Bind the built module
 */
export default require('../../build/Release/addon.node');
