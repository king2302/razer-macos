export class RazerDeviceAnimation {
  async init() {
    return this;
  }
  start() {}
  stop() {}
}