export class RazerDeviceType {}

RazerDeviceType.KEYBOARD = 'keyboard';
RazerDeviceType.MOUSE = 'mouse';
RazerDeviceType.MOUSEDOCK = 'mousedock';
RazerDeviceType.MOUSEMAT = 'mousemat';
RazerDeviceType.EGPU = 'egpu';
RazerDeviceType.HEADPHONE = 'headphone';
RazerDeviceType.ACCESSORY = 'accessory';